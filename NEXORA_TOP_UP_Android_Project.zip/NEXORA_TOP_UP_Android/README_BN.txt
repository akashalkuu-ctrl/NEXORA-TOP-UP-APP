NEXORA TOP UP Android App Project

এই ZIP-এ Android Studio-তে খোলার মতো সোর্স প্রজেক্ট আছে; তৈরি APK নয়।

APK বানানোর ধাপ:
1) কম্পিউটারে Android Studio ইনস্টল করো।
2) Android Studio থেকে এই ZIP extract করা NEXORA_TOP_UP_Android ফোল্ডার Open করো।
3) Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করো।
4) Build > Build Bundle(s) / APK(s) > Build APK(s) চাপো।
5) APK পাওয়া যাবে: app/build/outputs/apk/debug/app-debug.apk

অ্যাপের UI index.html এবং order.html থেকে চলে।
Order জমা দিলে WhatsApp-এ মেসেজ তৈরি হয়।
এই ভার্সনে অনলাইন Admin Dashboard, অর্ডার ডেটাবেস, স্বয়ংক্রিয় পেমেন্ট যাচাই বা বাস্তব Top-up API নেই।
পেমেন্ট করার আগে নম্বর ও মূল্য যাচাই করতে হবে।
